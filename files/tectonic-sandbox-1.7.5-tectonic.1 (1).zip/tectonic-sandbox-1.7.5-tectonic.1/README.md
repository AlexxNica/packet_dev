Please follow the instructions for setting up Tectonic Sandbox at https://coreos.com/tectonic/sandbox
